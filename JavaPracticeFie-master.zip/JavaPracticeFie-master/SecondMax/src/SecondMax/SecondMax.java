package SecondMax;
import java.util.*;
public class SecondMax {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Please Enter Size Of Array");
		int size=sc.nextInt();
		int arr[]=new int[size];
		int max=Integer.MIN_VALUE;
		int second_max=Integer.MIN_VALUE;
		int third_max=Integer.MIN_VALUE;
		System.out.println("Please Enter "+ size + " Element In Array");
		for(int i=0;i<size;i++)
		{
			arr[i]=sc.nextInt();
		}
		for(int i=0;i<size;i++)
		{
			if(max <arr[i])//arr[i]=40
			{
				third_max=second_max;
				second_max=max;//20//30
				max=arr[i];//30//40
				
			}
			else if(arr[i]>second_max && arr[i]!=max)
			{
				third_max=second_max;
				second_max=arr[i];//28
			}
			else if(arr[i]>third_max && arr[i]!=second_max)
			{
				third_max=arr[i];
				
			}
		}
		
		System.out.println(" Max : "+max);
		System.out.println("Second Max : "+second_max);
		System.out.println("third Max : "+third_max);


	}

}
