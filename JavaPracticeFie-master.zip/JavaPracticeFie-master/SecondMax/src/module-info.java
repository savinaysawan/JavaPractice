module SecondMax {
}