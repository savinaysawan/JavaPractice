package HashMap1;
import java.util.*;
public class HashMap1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String , Integer> m1=new HashMap<>();
		m1.put("Sawan", 101);
		m1.put("Kumar", 102);
		m1.put("Raj", 104);
		System.out.println(m1);
		System.out.println("Size of map is:- "
                + m1.size());
if (m1.containsKey("Sawan")) {

 // Mapping
 Integer a = m1.get("Sawan");

 // Printing value fr the corresponding key
 System.out.println("value for key"
                    + " \"Sawan\" is:- " + a);
		
 for (Map.Entry<String, Integer> e : m1.entrySet())
     System.out.println(e.getKey()+":"+e.getValue());
	}
	}

}
