module HashMap1 {
}