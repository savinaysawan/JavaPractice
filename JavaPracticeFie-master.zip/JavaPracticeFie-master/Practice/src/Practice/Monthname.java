package Practice;
import java.util.Scanner;
/* Input: Months number
 * Output: Number of Days in that Month.
 */
public class Monthname {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int []monthday= {31,28,31,30,31,30,31,31,30,31,30,31};
		System.out.println("Enter Month Number :");
		int data=sc.nextInt();
		System.out.println("Day in "+data +" Month is :"+monthday[data-1]);
		

	}

}
