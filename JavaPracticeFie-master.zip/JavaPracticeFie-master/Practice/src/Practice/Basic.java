package Practice;
import java.util.Scanner;
public class Basic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Size of Array ");
		int size=sc.nextInt();
		int []arr=new int[size];
		System.out.println("Enter Element in Array ");
		for(int i=0;i<size;i++)
		{
			arr[i]=sc.nextInt();//
		}
		
		System.out.println("Display Array Elements: ");
		for(int i=0;i<size;i++)
		{
			System.out.println("  "+arr[i]);//
		}
	}

}
