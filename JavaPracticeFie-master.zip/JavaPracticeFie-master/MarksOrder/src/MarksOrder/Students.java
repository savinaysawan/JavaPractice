package MarksOrder;

public class Students {
	private String Name;
	private double Marks;
	private int Age;
	public Students(String Name , double Marks , int Age)
	{
		this.Name=Name;
		this.Marks=Marks;
		this.Age=Age;
	}
	public String getName() {
		return Name;
	}

	public double getMarks() {
		return Marks;
	}

	public int getAge() {
		return Age;
	}
}
