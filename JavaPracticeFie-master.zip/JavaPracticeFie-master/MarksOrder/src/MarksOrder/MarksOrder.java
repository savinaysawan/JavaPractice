package MarksOrder;
import java.util.*;
public class MarksOrder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Students s1 = new Students("Sawan",68,21);
		Students s2 = new Students("Rishav",78,22);
		Students s3 = new Students("Abhishek",68,22);
		Students s4 = new Students("Rahul",83,23);
		Students s5 = new Students("Raj",85,24);
		TreeSet t1  = new TreeSet(new Comaparator1());
		t1.add(s1);
		t1.add(s2);
		t1.add(s3);
		t1.add(s4);
		t1.add(s5);
		
		Iterator it = t1.iterator();
		while(it.hasNext())
		{
			 Students sr = (Students)it.next();
			 System.out.println(sr.getName()+ " "+sr.getMarks()+" "+sr.getAge());
			
		}
		
		}

}
