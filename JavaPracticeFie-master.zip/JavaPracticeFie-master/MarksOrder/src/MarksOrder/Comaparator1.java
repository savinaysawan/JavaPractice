package MarksOrder;

import java.util.Comparator;

public  class Comaparator1 implements Comparator {
	public int  compare(Object o1 , Object o2)
	{
		Students s1 =(Students)o1;
		Students s2 =(Students)o2;
		if(s1.getMarks()<s2.getMarks() )
		{
			return -1;
		}
		else
		{
			return 1;
		}
		
	}

}
