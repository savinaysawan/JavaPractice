package SortedMap1;
import java.util.*;
public class SortedMap1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SortedMap<Integer,String> s1 = new TreeMap<Integer,String>();
		s1.put(1,"Sawan");
		s1.put(2,"Kumar");
		s1.put(3,"Raj");
		s1.put(4,"Rajesh");
		Set s = s1.entrySet();
        Iterator i = s.iterator();
        while (i.hasNext()) {
            Map.Entry m = (Map.Entry)i.next();
  
            int key = (Integer)m.getKey();
            String value = (String)m.getValue();
  
            System.out.println( key+" " +value);
        }
        SortedMap headMap = s1.headMap(3);

        System.out.println(headMap);
        
        SortedMap h1= s1.headMap(4);

        System.out.println(h1);
        
        SortedMap tail1 = s1.tailMap(3);

        System.out.println(tail1);

	}

}
