module SortedMap1 {
}