package Desc;
import java.util.*;
public class MyDesc implements Comparator {
	public int compare(Object o1 ,Object o2)
	{
		
		String t1=(String)o1;
		String t2=(String)o2;
		
		return -t1.compareTo(t2);
		//or return t2.compareTo(t1)
	}
	

}
