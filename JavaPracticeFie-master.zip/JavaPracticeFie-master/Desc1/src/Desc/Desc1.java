package Desc;

import java.util.TreeSet;

public class Desc1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet tr1=new TreeSet(new MyDesc());
		
		tr1.add("A");
		tr1.add("B");
		tr1.add("D");
		tr1.add("E"); 
		tr1.add("C");
       System.out.println(tr1);
	}

}
