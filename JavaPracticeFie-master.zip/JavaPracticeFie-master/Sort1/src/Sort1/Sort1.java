package Sort1;
import java.util.*;
public class Sort1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Hashtable <String , Integer> table1 = new Hashtable<>();
 
  table1.put("A", 21);
  table1.put("B", 3);
  table1.put("C", 4);
  table1.put("D", 15);
  table1.put("E", 14);
  table1.put("F", 10);
  TreeSet  s1= new TreeSet(table1.values());
  Iterator it =  s1.iterator();
  while(it.hasNext())
  {
	  int temp =(Integer) it.next();
	  for(Map.Entry<String, Integer> e1: table1.entrySet()) {

	      // if give value is equal to value from entry
	      // print the corresponding key
	      if(e1.getValue() == temp) 
	      {
	    	  System.out.println(e1.getKey());
	      }
	  }
  }
  System.out.println(s1);
  }

}
