
package towerOfHanoi;
import java.util.*;
public class towerOfHanoi {
	static void towerOfHanoi(int n,char s,char h,char d)
	{
		if(n==0)
		{
			return ;
		}
		else
		{
			towerOfHanoi(n-1,s,d,h);
			System.out.println("Movement Of Disk " + n +" From  road : "+s +" to road  "+ d);
			towerOfHanoi(n-1,h,s,d);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Value Of N");
		int n=sc1.nextInt();
        towerOfHanoi(n,'s','h','d');
	}

}
