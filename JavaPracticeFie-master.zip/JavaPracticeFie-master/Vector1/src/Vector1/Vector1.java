package Vector1;
import java.util.*;
public class Vector1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector v1=new Vector(10);
		v1.addElement(10);
		v1.addElement(20);
		v1.addElement(30);
		v1.addElement(40);
		v1.add(50);//From collection interface
		v1.add(60);//From Collection interface 
		v1.add(6, 70);//From list interface
		System.out.println("Vector Elements Are :");
		System.out.println(v1);
		System.out.println("Vector Size is:"+v1.size());
		System.out.println("Vector Capacity is:"+v1.capacity());
		v1.removeElementAt(4);
		System.out.println("Vector Elements Are :");
		System.out.println(v1);
		System.out.println("Vector Size is:"+v1.size());
		System.out.println("Vector Capacity is:"+v1.capacity());
		v1.remove(2);
		System.out.println("Vector Elements Are :");
		System.out.println(v1);
		System.out.println("Vector Size is:"+v1.size());
		System.out.println("Vector Capacity is:"+v1.capacity());
		System.out.println("First Element of Vector : "+v1.firstElement());
		System.out.println("Last Elements of Vector :"+v1.lastElement());
		Vector v2 = new Vector(2,3);
		v2.addElement(10);
		v2.addElement(20);
		v2.addElement(30);
		System.out.println("Vector Size is:"+v2.size());
		System.out.println("Vector Capacity is:"+v2.capacity());
		
		
		

	}

}
