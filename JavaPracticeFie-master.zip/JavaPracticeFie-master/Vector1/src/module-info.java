module Vector1 {
}