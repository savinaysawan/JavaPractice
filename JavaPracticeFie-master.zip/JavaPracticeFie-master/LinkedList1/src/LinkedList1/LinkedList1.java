package LinkedList1;
import java.util.*;
public class LinkedList1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList l1 = new LinkedList();
		l1.add(10);
		l1.add(20);
		l1.add(30);
		l1.add(40);
		l1.add(50);
		System.out.println(l1);
		System.out.println(l1.get(2));
		System.out.println(l1.get(3));
		System.out.println(l1.getFirst());
		System.out.println(l1.getLast());
		

	}

}
