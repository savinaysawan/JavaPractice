package TreeSet2;
import java.util.*;
public class TreeSet2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NavigableSet ns = new TreeSet();
        ns.add(0);
        ns.add(1);
        ns.add(2);
        ns.add(3);
        ns.add(4);
        ns.add(5);
        ns.add(6);
        System.out.println(ns);
        
        
        System.out.println("lower(3): " + ns.lower(3));
        System.out.println("floor(3): " + ns.floor(3));
        System.out.println("higher(3): " + ns.higher(3));
        System.out.println("ceiling(3): " + ns.ceiling(3));
        System.out.println("pollFirst(): " + ns.pollFirst());
        System.out.println("Navigable Set:  " + ns);

	}

}
