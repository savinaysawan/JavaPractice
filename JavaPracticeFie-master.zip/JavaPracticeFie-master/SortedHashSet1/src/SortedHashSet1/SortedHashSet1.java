package SortedHashSet1;
import java.util.*;
public class SortedHashSet1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SortedSet t1 = new TreeSet();
		t1.add("A");
		t1.add("D");
		t1.add("B");
		t1.add("C");
		System.out.println(t1);
		System.out.println("First Object : "+t1.first());
		System.out.println("Last Object  : "+t1.last());
		System.out.println("HeadSet of c : "+t1.headSet("C"));
		System.out.println("TailSet of c : "+t1.tailSet("C"));
		
	
		
		
		
		

	}

}
