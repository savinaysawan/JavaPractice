package Recursion;

public class Recursion_Test {
static void Print1(int n,int p)
{
	if(n==0)
	{
		System.out.println("n=0");
	}
	else
	{   System.out.println("IN else Statement :");
		for(int i=p ;i<3 ;i++)
		{
			System.out.println("Value Of i= "+i);
			Print1(n-1,i+1);
			System.out.println("Value Of i After Recursion = "+i);
		}
	}
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Print1(7,0);

	}

}
