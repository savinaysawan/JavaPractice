module sumNatural {
}