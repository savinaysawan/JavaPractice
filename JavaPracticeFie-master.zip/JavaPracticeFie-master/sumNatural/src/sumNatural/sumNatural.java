package sumNatural;
import java.util.*;
public class sumNatural {
	static int Sum(int n)
	{
		if(n==0 || n==1)
		{
			return n;
		}
		else
		{
		  return n+Sum(n-1);	
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter value Of N : ");
		Scanner sc1=new Scanner(System.in);
		int n=sc1.nextInt();
		System.out.println("Sum Of First  :"+n +" Natural Number is : "+Sum(n));

	}

}
