package sumNatural;

import java.util.Scanner;

public class calPower {
	static int Power(int x,int n)
	{
		if(x==0)
		{
			return 0;
		}
		if(n==0)
		{
			return 1;
		}
		
		 else
		{
			 int pown=Power(x,n/2);
			if(n%2==0)
			{
				return pown*pown;
			}
			else
			{
				return pown*pown*x;
			}
		}
		 
		 /*else
		 {
			 return x*Power(x,n-1);
		 }
		 */
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Value Of x  : ");
		int x=sc1.nextInt();
		System.out.println("Enter Value Of N  : ");
		int n=sc1.nextInt();
		System.out.println("Power  Of "+x+" to   :"+n+ "is :" +Power(x,n));

	}

}
