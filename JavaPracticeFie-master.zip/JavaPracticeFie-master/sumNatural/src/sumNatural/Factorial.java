package sumNatural;
import java.util.*;
public class Factorial {
     static int Fib(int n)
     {
    	 if(n==0 || n==1)
    	 {
    		 return 1;
    	 }
    	 else
    	 {
    		 return n*Fib(n-1);
    	 }
     }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Value Of N  : ");
		int n=sc1.nextInt();
		System.out.println("Factorial Of "+n+" Number is  :"+Fib(n));

	}

}
