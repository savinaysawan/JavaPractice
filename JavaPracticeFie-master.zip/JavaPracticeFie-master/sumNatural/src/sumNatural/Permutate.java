package sumNatural;
import java.util.*;
public class Permutate {
	public static String Swap(String a,int i,int j)
	{
		char temp;
		char [] str1=a.toCharArray();//convert string to char array
		temp=str1[i];
		str1[i]=str1[j];
		str1[j]=temp;
		return String.valueOf(str1);
		
	}
static void Per(String str,int l,int r)
{
	if(l==r)
	{
		  System.out.println(str);
	}
	else
	{
		for(int i=l;i<r;i++)
		{
			str=Swap(str,l,i);
			Per(str,l+1,r);
			str=Swap(str,l,i);
			
		}
	}
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter String For Permutation");
		String s1=sc1.nextLine();
		int size=s1.length();
		System.out.println("All Permutation of String "+s1+"   is  : ");
		Per(s1,0,size);

	}
	

}
