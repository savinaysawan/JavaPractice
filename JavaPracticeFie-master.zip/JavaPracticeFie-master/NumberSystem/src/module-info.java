module NumberSystem {
}