package Number;
import java.util.*;
public class sumOfBase {
	public static int sumNumber(int n1,int n2, int base)
	{
		int res=0;
		int carry=0;
		int d1,d2,d;
		int pow=1;
		while(n1 >0 || carry>0 || n2>0)
		{
			d1=n1%10;
			n1=n1/10;
			d2=n2%10;
			n2=n2/10;
			d=d1+d2+carry;//Adding both digit with carry
			d=d%base;
			carry=d/base;
			res=res+d*pow;//Returning result in opposite manner 
			pow=pow*10;
			}
		return res;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter 1st  Number for Addition");
		int n1=sc1.nextInt();
		System.out.println("Enter 2nd  Number for Addition");
		int n2=sc1.nextInt();
		System.out.println("Enter Base ");
		int b=sc1.nextInt();
		System.out.println("Sum Of : "+ n1+"   And  "+n2+ " Is  : "+sumNumber(n1,n2,b));

	}

}
