package Number;
import java.util.*;
public class mulNumber {
	public static int getSum(int n1,int n2, int base)
	{
		int res=0;
		int carry=0;
		int d1,d2,d;
		int pow=1;
		while(n1 >0 || carry>0 || n2>0)
		{
			d1=n1%10;
			n1=n1/10;
			d2=n2%10;
			n2=n2/10;
			d=d1+d2+carry;//Adding both digit with carry
			d=d%base;
			carry=d/base;
			res=res+d*pow;//Returning result in opposite manner 
			pow=pow*10;
			}
		return res;
	}
	public static int prodNumber(int n1,int n2,int base)
	{
		int fin_res=0;
		int single_prod=0;
		int rem=0;
		int pow=1;
		while(n2>0)
		{
			rem=n2%10;
			n2=n2/10;
			single_prod=getSingleMul(n1,rem,base);
			single_prod=single_prod*pow;
			pow=pow*10;
			fin_res=getSum(fin_res,single_prod, base );
			
			
		}
		return fin_res;
	}
	
	public static int getSingleMul(int n1, int n2, int base)
	{
		int res=0;
		int pow=1;
		int d=0;
		int d1;
		int carry=0;
		while(n1>0)
		{
			d1=n1%10;
			n1=n1/10;
			d = d1*n2 +carry;
			carry=d/10;
			d=d%10;
			res=res+d*pow;
			pow=pow*10;
			
		}
		return res;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter 1st  Number for Addition");
		int n1=sc1.nextInt();
		System.out.println("Enter 2nd  Number for Addition");
		int n2=sc1.nextInt();
		System.out.println("Enter Base ");
		int b=sc1.nextInt();
		System.out.println("Difference  Of : "+ n1+"   And  "+n2+ " Is  : "+prodNumber(n1,n2,b));
		

	}

}
