package Number;

import java.util.Scanner;

public class getDiff {
	public static int diffNumber(int n1,int n2, int base)
	{
		int res=0;
		int carry=0;
		int d1,d2,d;
		int pow=1;
		while(n1 >0 || n2>0)
		{
			d1=n1%10;
			n1=n1/10;
			d2=n2%10;
			n2=n2/10;
			d1=d1+carry;//Substracting carry from second digit 
			if(d1>=d2)
			{
				carry=0;
				d=d1-d2;
			}
			else
			{
				carry=-1;
				d=d1+base-d2;
			}
			res=res+d*pow;
			pow=pow*10;
			
			}
		return res;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter 1st  Number for Addition");
		int n1=sc1.nextInt();
		System.out.println("Enter 2nd  Number for Addition");
		int n2=sc1.nextInt();
		System.out.println("Enter Base ");
		int b=sc1.nextInt();
		System.out.println("Difference  Of : "+ n1+"   And  "+n2+ " Is  : "+diffNumber(n1,n2,b));


	}

}
