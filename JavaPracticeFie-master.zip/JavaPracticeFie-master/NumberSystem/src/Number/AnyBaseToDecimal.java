package Number;

import java.util.Scanner;

public class AnyBaseToDecimal {
	public static int baseToDecimal(int n,int b)
	{
		int res=0;
		int rem=0;
		int pow=1;
		while(n!=0)
		{
			rem=n%10;
			res=res+rem*pow;
			pow=pow*b;
			n=n/10;
		}
		return res;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter  Number for Conversion");
		int n=sc1.nextInt();
		System.out.println("Enter Base value  for Number");
		int b=sc1.nextInt();
		System.out.println("Number "+n+"  of base  "+b +"  Decimal Value Is :  "+baseToDecimal(n,b));
		

	}

}
