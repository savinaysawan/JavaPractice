package Number;
import java.util.*;
public class NumberSystem {
	public static int DecimalToBase(int n,int b)
	{
		int power=1;
		int res=0;
		int rem=0;
		while(n!=0)
		{
			rem=n%b;
			res=res+rem*power;
			power=power*10;
			n=n/b;
		}
		return res;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Decimal Number for Conversion");
		int n=sc1.nextInt();
		System.out.println("Enter Base value  for Conversion");
		int b=sc1.nextInt();
		System.out.println("Decimal "+n+"  to "+b +" Value Is :  "+DecimalToBase(n,b));
		

	}

}
