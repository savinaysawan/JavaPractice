module Shape {
}