package Shape;

public class Fruite {
	String Name;
	String Color;
	double Price;
	public Fruite(String n1 , String c1 , double p1)
	{
		Name =n1;
		Color =c1;
		Price =p1;
	}
	void Display()
	{
		System.out.println("Name :"+Name);
		System.out.println("Colour :"+Color);
		System.out.println("Price :"+Price);
	}

}
