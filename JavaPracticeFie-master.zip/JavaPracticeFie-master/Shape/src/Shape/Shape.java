package Shape;

public class Shape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Fruite f1= new Fruite("Mango","Yellow",10.50);
		System.out.println("Your Data is : \n");
		f1.Display();
		Fruite f2= new Fruite("Banana","Yellow",2.50);
		System.out.println("Your Data is : \n");
		f2.Display();
		

	}

}
