package Tree_Sample;

public class Tree_Sample {
	 //Data-->Left-->Right
	static int count_leaf=0;
	static void preOrder(Node node)
	{
		if(node==null)
			return;
		System.out.print(node.data +"  -->  ");
		preOrder(node.left);
		preOrder(node.right);
		
	}
	
	//Left-->Data-->Right
	static void inOrder(Node node)
	{
		if(node==null)
			return;
		inOrder(node.left);
		System.out.print(node.data +"  -->  ");
		inOrder(node.right);
	}
  //Left-->Right-->Data
	static void postOrder(Node node)
	{
		if(node==null)
			return;
		postOrder(node.left);
		postOrder(node.right);
		System.out.print(node.data +"  -->  ");
	}
	static int findMax(Node rootNode)
	{
	   if(rootNode==null)
	   {
		   return Integer.MIN_VALUE;
	   }
	   int res=rootNode.data;//data
	   int left=findMax(rootNode.left);//left
	   int right=findMax(rootNode.right);//right
	   if(left > res)//compare with max & assign max
	   {
		   res=left;
	   }
	   if(right > res)
	   {
		   res=right;
	   }
	   return res;
	  
	}
	//finding minimum
	static int findMin(Node rootNode)
	{
	   if(rootNode==null)
	   {
		   return Integer.MAX_VALUE;
	   }
	   int res=rootNode.data;//data
	   int left=findMin(rootNode.left);//left
	   int right=findMin(rootNode.right);//right
	   if(left < res)//compare with max & assign max
	   {
		   res=left;
	   }
	   if(right < res)
	   {
		   res=right;
	   }
	   return res;
	  
	}
	static void  leafNode_count(Node node)
	{
	   if(node ==null)
		   return;
	   if(node.left==null && node.right==null)
	   {
		   count_leaf++;
	   }
	   leafNode_count(node.left);
	   leafNode_count(node.right);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Node root= new Node(10);
		Node n2= new Node(12);
		Node n3= new Node(13);
		Node n4= new Node(16);
		Node n5= new Node(18);
		Node n6= new Node(20);
		Node n7= new Node(24);
		Node n8= new Node(26);
		root.left=n2;
		root.right=n3;
		n2.left=n4;
		n2.right=n5;
		n3.left=n6;
		n3.right=n7;
		n7.right=n8;
		System.out.println("Inorder traversal");
	    inOrder(root);
		System.out.println("\nPreorder traversal ");
		preOrder(root);
        System.out.println("\nPostorder traversal");
		postOrder(root);
		System.out.println("\nLEAF NODE COUNT::::::");
		leafNode_count(root);
		System.out.println("Leaf Node count is : "+count_leaf);
		System.out.println("Maximum of the Tree Is :   " +findMax(root));
		System.out.println("Minimun of the Tree Is :   " +findMin(root));
		
		

		

	}

}
