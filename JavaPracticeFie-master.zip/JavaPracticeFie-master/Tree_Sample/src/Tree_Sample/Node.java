package Tree_Sample;

public class Node {
	int data;
	Node left=null;
	Node right=null;
	public Node(int data)
	{
		this.data=data;
	}

}
