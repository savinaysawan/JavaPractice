package Missing;
import java.util.*;
public class MissingValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Size Of Array ");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter Size Of Array ");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		int sum=(n+1)*(n+2)/2;
		for(int i=0;i<n;i++)
		{
			sum=sum-arr[i];
		}
		System.out.println("Missing Value Of Array is : " + sum);

	}

}
