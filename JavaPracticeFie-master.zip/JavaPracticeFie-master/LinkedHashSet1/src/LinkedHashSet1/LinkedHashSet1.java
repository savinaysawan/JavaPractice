package LinkedHashSet1;
import java.util.*;
public class LinkedHashSet1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashSet l1=new LinkedHashSet(20);
		l1.add(10);
		l1.add(20);
		l1.add(23);
		l1.add(34);
		l1.add(45);
		System.out.println("IN LinkedHashSet Order is preserved : ");
		System.out.println(l1);
		HashSet l2=new HashSet(20);
		l2.add(10);
		l2.add(20);
		l2.add(23);
		l2.add(34);
		l2.add(45);
		System.out.println("IN HashSet Order is not  preserved : ");
		System.out.println(l2);
		

	}

}
