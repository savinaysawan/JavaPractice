module Collection_ArrayList1 {
}