
public class Collection_ArrayList1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
