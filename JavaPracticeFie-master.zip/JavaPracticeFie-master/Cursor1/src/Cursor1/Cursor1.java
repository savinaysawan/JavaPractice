package Cursor1;
import java.util.*;
public class Cursor1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList l1=new LinkedList();
		l1.add("A");
		l1.add("B");
		l1.add("C");
		l1.add("D");
		System.out.println(l1);
		ListIterator list1=l1.listIterator();
		while(list1.hasNext())
		{
			String s1=(String) list1.next();
			System.out.println(s1);//printing Linkedlist elements
			if(s1.equals("D"))
			{
				list1.set("Don");
			}
		}
		System.out.println("Updated List Elements:");
		System.out.println(l1);
		
	}

}
