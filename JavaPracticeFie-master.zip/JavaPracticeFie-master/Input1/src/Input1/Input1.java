package Input1;
import java.util.*;
public class Input1 {

	public static void main(String[] args) {
		// TODO Auto-generated method 
		Hashtable <String,Integer> has1 = new Hashtable<>();
		has1.put("A", 5);
		has1.put("B", 6);
		has1.put("C", 3);
		has1.put("D", 4);
		has1.put("E", 3);
		System.out.println(has1);
		for(Map.Entry var1 : has1.entrySet())
		{
			int temp =(Integer) var1.getValue();
			if(temp>=5)
			{
				System.out.println(var1.getKey());
			}
		}
		
		
		
		

	}

}
