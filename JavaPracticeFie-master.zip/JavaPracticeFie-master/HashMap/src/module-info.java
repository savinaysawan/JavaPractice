module HashMap {
}