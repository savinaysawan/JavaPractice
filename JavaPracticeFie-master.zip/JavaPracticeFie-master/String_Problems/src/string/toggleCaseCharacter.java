package string;
import java.util.*;
public class toggleCaseCharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Input String For toggling character");
		String str=sc.nextLine();
		StringBuilder sb=new StringBuilder(str);
		for(int i=0;i<sb.length();i++)
		{
			char ch=sb.charAt(i);
			if(ch>='a'&&ch<='z')
			{
				char uc=(char)(ch-'a'+'A');
				sb.setCharAt(i, uc);
			}
			else
			{
				char lc=(char)(ch-'A'+'a');
				sb.setCharAt(i, lc);
			}
			
		}
		String res=sb.toString();
		System.out.println("Output String :"+res);

	}

}
