package string;
import java.util.*;
/*
 * string compression 
 * Input : aaaabbbcccddeeef
 * Output: a4b3c3d2e3f
 */
public class stringCompression2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Input String For Compression");
		String str=sc.nextLine();
		String outstr="";
		char c=str.charAt(0);
		outstr=outstr+c;//put first value 
		int count=1;//start counter with 1
		for(int i=1;i<str.length();i++)
		{
			char curr=str.charAt(i);
			char prev=str.charAt(i-1);
			if(curr==prev)//if we get same  value then we inc counter.
			{
				count++;
			}
			else//if both character is not equal 
			{
				if(count>1)//if count more than 1 then print output string with count
				{
					outstr=outstr+count;
					count=1;//again set count to 1
				}
				outstr=outstr+curr;//if count is 1 the don't need to put count along with string 
				//directly displaying that value 
			}
		}
		System.out.println("Output  String After  Compression");
	System.out.println(outstr);
	}

}
