package string;
import java.util.*;
public class permutationOfString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Input String");
		String str=sc.nextLine();
		
		int fact=1;
		for(int i=2;i<=str.length();i++)
		{
			fact=fact*i;
		}
		System.out.println("no of permutation of given String "+fact);
		System.out.println("String Is: ");
		for(int i=0;i<fact;i++)
		{
			StringBuilder sb=new StringBuilder(str);
			int temp=i;
			for(int div=str.length();div>=1;div--)
			{
				int q=temp/div;
				int r=temp%div;
				System.out.print(sb.charAt(r));
				sb.deleteCharAt(r);
				temp=q;
			}
			System.out.println();
		}

	}

}
