package string;
import java.util.*;
public class printlAllPalindrom {
	public static boolean isPalindrom(String s)
	{
		int i=0;
		int j=s.length()-1;
		while(i<=j)
		{
			char c=s.charAt(i);
			char l=s.charAt(j);
			if(c!=l)
			{
				return false;
			}
			else
			{
				i++;
				j--;
			}
			
		}
		return true;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter String : ");
		Scanner sc=new Scanner(System.in);
		String s1=sc.nextLine();
		System.out.println("palindrom of Substring of Given String : "+s1);
		for(int i=0;i<s1.length();i++)
		{
			for(int j=i+1;j<=s1.length();j++)
			{
				String s=s1.substring(i,j);
				if(s.length()>1)
				{
				if(isPalindrom(s)==true)
				{
					System.out.println(s);
				}
			}
		}

	}
	}
}
