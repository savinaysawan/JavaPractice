package string;
import java.util.*;
public class stringBuilderBasicFunction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder sb=new StringBuilder("Hello");
		//add element from last 
		sb.append('g');
		System.out.println(sb);
		//insert particular char at particular position
		sb.insert(3, 'f');
		System.out.println(sb);
		//deleting character from string 
		sb.deleteCharAt(0);
		System.out.println(sb);

	}

}
