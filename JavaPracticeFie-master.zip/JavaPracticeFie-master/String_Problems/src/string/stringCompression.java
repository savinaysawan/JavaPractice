package string;
import java.util.*;
/*
 * string compression 
 * Input : aaaabbbcccddeeef
 * Output: abcdef
 */
public class stringCompression {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Input String For Compression");
		String str=sc.nextLine();
		String outstr="";
		char c=str.charAt(0);
		outstr=outstr+c;//put first value 
		for(int i=1;i<str.length();i++)
		{
			char curr=str.charAt(i);
			char prev=str.charAt(i-1);
			if(curr!=prev)//if we get new value then we put that into output.
			{
				outstr=outstr+curr;
			}
		}
		System.out.println("Output  String After  Compression");
	System.out.println(outstr);
	}

}
