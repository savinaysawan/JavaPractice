package string;
import java.util.*;
public class printAllSubstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter String : ");
		Scanner sc=new Scanner(System.in);
		String s1=sc.nextLine();
		System.out.println("Substring of Given String : "+s1);
		for(int i=0;i<s1.length();i++)
		{
			for(int j=i+1;j<=s1.length();j++)
			{
				System.out.println(s1.substring(i,j));
			}
		}

	}

}
