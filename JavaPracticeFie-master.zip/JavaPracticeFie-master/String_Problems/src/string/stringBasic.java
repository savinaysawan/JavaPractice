package string;

public class stringBasic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Hello";
		String str1="Hello";
		String str2= new String("Hello");
		
		System.out.println("Output Using == operator \n");
		if(str==str1)//it compare the address part .so, both string are on same addr.
		{
			System.out.println("Both(str1 && str  are Equal");
		}
		else
		{
			System.out.println("Both(str1 && str)   are Not  Equal");
		}
		if(str1==str2)//One string str2 created using new keyword so ,they are not on same addrr.
		{
			System.out.println("Both(str1 & str2 )  are Equal");
		}
		else
		{
			System.out.println("Both(str1 & str2 )  are Not Equal");
		}
		//if we want to check the string character 
		//equals function check addr first then it check content . so,this is more suitable for 
		//string comparison 
		System.out.println("\nOutput Using equals  function \n");
		if(str.equals(str1))//it compare the address part .so, both string are on same addr.
		{
			System.out.println("Both(str1 && str  are Equal");
		}
		else
		{
			System.out.println("Both(str1 && str)   are Not  Equal");
		}
		if(str1.equals(str2))//One string str2 created using new keyword so ,they are not on same addrr.
		{
			System.out.println("Both(str1 & str2 )  are Equal");
		}
		else
		{
			System.out.println("Both(str1 & str2 )  are Not Equal");
		}
		//finding string length
		System.out.println("String Length IS : "+str.length());
		//use of carAt function
		System.out.println(str.charAt(2));
		System.out.println(str.charAt(0));
		//substring function
		//used to print element from start to end-1 
		//if we provide only one parameter ten it print all element from that element
		System.out.println("workin of Substring Function");
		System.out.println("str.substring(0,3) : "+str.substring(0,3));
		System.out.println("str.substring(1) : "+str.substring(1));
		String s="Hi Sawan How are You ?";
		System.out.println("workin of Split  Function");
		String [] parts=s.split(" ");
		for(int i=0;i<parts.length;i++)
		{
			System.out.println(parts[i]);
		}
		String s1="Hi,Sawan,How,are,You,?";
		System.out.println("workin of Split  Function");
		String [] parts2=s1.split(",");
		for(int i=0;i<parts2.length;i++)
		{
			System.out.println(parts2[i]);
		}
				

	}

}
