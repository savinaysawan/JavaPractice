package string;
import java.util.*;
public class maxConsucative {
	public static void maxconstr(String str,int size)
	{
		int count=1;
		int max=0;
		
		char c[]=str.toCharArray();
		char maxchar=c[0];
		for(int i=0;i<size;i++)
		{
			if(c[i]==c[i+1] && i<size-1)//checking consecutive char
			{
				count++;
			}
			else
			{
				if(count > max)//check new count is greater or not
				{
					maxchar=c[i];
					max=count;
				}
				count=1;
			}
		}
		System.out.println("Maximum consucative value:"+max);
		System.out.println("character haviing maximum consucative value :"+maxchar);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Input String");
		String str=sc.nextLine();
		maxconstr(str,str.length()-1);
		

	}

}
