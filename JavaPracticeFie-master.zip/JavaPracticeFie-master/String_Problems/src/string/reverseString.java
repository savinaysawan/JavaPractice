package string;
import java.util.*;
public class reverseString {
	public static String reverseStr(String str,int s,int e)
	{
		char c[]=str.toCharArray();//converting String into character Array
		while(s<=e)//whenever Start is lesser than End
		{
			char temp;
			temp=c[s];
			c[s]=c[e];
			c[e]=temp;
			s++;
			e--;
		}
		return String.valueOf(c);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Input String");
		String str=sc.nextLine();
		System.out.println("Original String :     "+str);
		String out=reverseStr(str,0,str.length()-1);
		System.out.println("String After Reverse :"+out);

	}

}
