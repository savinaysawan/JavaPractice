module String_Problems {
}