module freqDig {
}