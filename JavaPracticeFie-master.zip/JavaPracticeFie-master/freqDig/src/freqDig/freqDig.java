package freqDig;
import java.util.*;
public class freqDig {
	public static int Fre(int [] arr,int key)
	{
		int count=0;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==key)
			{
				count++;
			}
		}
		return count;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter The Size of Array ");
		int n=sc1.nextInt();
		int [] arr=new int[10];
		System.out.println("Enter element in Array ");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc1.nextInt();
		}
		System.out.println("Enter Key  ");
		int key =sc1.nextInt();
		System.out.println("Frequecy Of "+key+"  is :"+Fre(arr,key));
		

	}

}
