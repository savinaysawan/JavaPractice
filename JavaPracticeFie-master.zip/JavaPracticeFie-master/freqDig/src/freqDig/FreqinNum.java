package freqDig;
import java.util.*;
public class FreqinNum {
	public static int FreN(int n,int key)
	{
		int count=0;
		while(n!=0)
		{
			if(n%10==key)
			{
				count++;
			}
			n=n/10;
		}
		return count;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Number ");
		int n=sc1.nextInt();
		
		System.out.println("Enter Key  ");
		int key =sc1.nextInt();
		System.out.println("Frequency of : "+key+"  is:  "+ FreN(n,key));

	}

}
