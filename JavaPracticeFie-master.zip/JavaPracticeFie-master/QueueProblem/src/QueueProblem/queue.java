package QueueProblem;

import java.util.Scanner;

//import Stack_Problem.stackUsingClass.stackClass;

public class queue {
	public static class Queue
	{
		int front,rear,capacity;
		int q1[];
		Queue(int cap)
		{
			front=rear=0;
			capacity=cap;
			q1= new int[capacity];
		}
		// insert element into queue
		void enqueue(int ele)
		{
			if(rear==q1.length)
			{
				System.out.println("Queue is full further enque is not possible \n");
			}
			else
			{
				q1[rear++]=ele;
			}
		}
		//delete element from queue
		int dequeue()
		{
			if(rear==0)
			{
				System.out.println("No element in the queue to dequeue");
				return -1;
			}
			else
			{
				int i;
				int val=q1[front];
				for(i=0;i<rear-1;i++)
				{
					q1[i]=q1[i++];
				}
				q1[rear]=0;
				rear--;
				return val;
				
			}
		}
		//front of queue
		int front()
		{
			return q1[front];
		}
		//rear of queue
		int rear()
		{
			if(rear ==0)
			{
				return -1;
				
			}
			else 
			{
			return q1[rear-1];
			}
		}
		void display()
		{
			for(int j=0;j<rear;j++)
			{
				System.out.print(q1[j]+"  ");
			}
			System.out.println();
		}
	}



	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc1= new Scanner(System.in);
		/*
		 * User name and greeting
		 */
		System.out.println("Your Good Name Please :  ");
		String name =sc1.nextLine();
		System.out.println("Hi  "+name +"  Welcome \n");
		System.out.println("Enter Size of queue that you want to create  ");
		int si=sc1.nextInt();
		Queue qt=new Queue(si);
		boolean i=true;
		while(i )
		{
			
			System.out.println("\n\nPress : 1  --->  for Push an element into Queue");
			System.out.println("Press : 2  --->  for Pop an element from Queue");
			System.out.println("Press : 3  --->  for first  element into Queue");
			System.out.println("Press : 4  --->  for last element of  Queue");
			System.out.println("Press : 5  --->  for Display all element of Queue");
			System.out.println("Press : any other integer to come out of loop  ");
			System.out.println("\n\nHi "+name+"   Please Enter Your Chioce given above");
			int s= sc1.nextInt();
			switch(s)
			{
			case 1:
				System.out.println("Enter element for queue ");
				int ele=sc1.nextInt();
				qt.enqueue(ele);
				break;
			case 2:
				int k=qt.dequeue();
				if(k!=-1)
				{
					System.out.println("dequeue element : "+k);
				}
				else
				{
					System.out.println("Not possible:");
				}
				break;
			case 3:
				System.out.println("front element of queue is :"+qt.front());
				break;
			case 4:
				int k2=qt.rear();
				if(k2 !=-1)
				{
					System.out.println("rear element of Stack  : "+k2);
				}
				else
				{
					System.out.println("No rear Element :");
				}
				break;
			case 5:
				System.out.println(" Element  of queue IS :");
				qt.display();
				break;
			default :
				i=false;
				break;
		}
	}
}
}

