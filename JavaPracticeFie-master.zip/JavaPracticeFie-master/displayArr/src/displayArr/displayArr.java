package displayArr;
import java.util.*;
public class displayArr {
	public static int displayMax(int [] arr,int ind)
	{
		if(ind==arr.length-1)
		{
			return arr[ind];
		}
		int max1=displayMax(arr,ind+1);
		if(max1>arr[ind])
		{
			return max1;
		}
		else
		{
			return arr[ind];
		}
		
	}
	
	public static int displayMin(int [] arr,int ind)
	{
		if(ind==arr.length-1)
		{
			return arr[ind];
		}
		int mini=displayMin(arr,ind+1);
		if(mini<arr[ind])
		{
			return mini;
		}
		else
		{
			return arr[ind];
		}
		
	}
	
	public static void displayArray(int [] arr,int ind)
	{
		if(arr.length==ind)
		{
			return ;
		}
		System.out.println(arr[ind]);
		displayArray(arr,ind+1);
	}
	public static void reverseArray(int [] arr,int ind)
	{
		if(ind==-1)
		{
			return ;
		}
		System.out.println(arr[ind]);
		reverseArray(arr,ind-1);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Size Of Array");
		int n=sc1.nextInt();
		int []arr=new int[n];
		System.out.println("Enter Element of Array:");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc1.nextInt();
		}
		System.out.println("Enter Value From Which You want to display Array");
		int k=sc1.nextInt();
		System.out.println("Array Element From  :   "+k+"   Element Is :");
		displayArray(arr,k);
		System.out.println("Enter Value From Which You want to display Array in Reverse Order ");
		int k1=sc1.nextInt();
		System.out.println("Array Element From last :   "+k1+"    Is :");
		reverseArray(arr,k1);
		System.out.println("Maximum of Array is : "+ displayMax(arr,k));
		System.out.println("Minimum of Array is : "+ displayMin(arr,k));

	}

}
