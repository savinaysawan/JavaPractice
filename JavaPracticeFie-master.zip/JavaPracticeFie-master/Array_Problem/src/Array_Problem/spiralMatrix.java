package Array_Problem;

import java.util.Scanner;

public class spiralMatrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int row1, col1;
	    Scanner s = new Scanner(System.in);
	    System.out.print("Enter number of rows in matrix:");
	    row1 = s.nextInt();
	    System.out.print("Enter number of columns in  matrix:");
	    col1 = s.nextInt();
	    int [][] a=new int[row1][col1];
	    System.out.println("Enter values for matrix A : \n");
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) 
                a[i][j] = s.nextInt();
        }
        
        System.out.println("Your Input Matrix  : \n");
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) {
                System.out.print(a[i][j]+"\t");}
            System.out.println();
        }
        
        int min_row=0;
        int min_col=0;
        int i,j;
        int max_row=row1-1;
        int max_col=col1-1;
        int tne=row1*col1;
        int count=0;
        System.out.println("Your Matrix  Element In Spiral form : \n");
        while(count < tne )
        {
        	//left wall row changes from min_row to  max_row col is fixed at min_col
        	for( i=min_row ,j=min_col;i<=max_row && count< tne ;i++)
        		//checking total_number of element greater than count
        	{
        		System.out.println(a[i][j]);
        		count++;//inc count 
        	}
        	//condition to remove corner :use only once
        	min_col++;
        	//bottom wall where row value is fixed at max_row while col changes from min_col to max_col
        	for( i=max_row,j=min_col;j<=max_col && tne >count ;j++)
        	{
        		System.out.println(a[i][j]);
        		count++;//inc count 
        	}
        		
        	max_row--;//condition to remove corner : corner use only once
        	//right wall col fixed at max_col row changes from max_row to min_row(dec)
        	for( i=max_row, j=max_col;i>=min_row && tne >count ;i--)
    
        	{
        		System.out.println(a[i][j]);
        		count++;//inc count 
        	}
        	max_col--;//condition to remove corner : corner use only once
        	//Top wall row is fixed at min_row col is canges from max_col to min_col(dec)
        	for(i=min_row,j=max_col;j>=min_col && tne>count;j--)
        	{
        		System.out.println(a[i][j]);
        		count++;//inc count 
        	}
        	min_row++;//for starting  of next spiral
        	}

	}

}
