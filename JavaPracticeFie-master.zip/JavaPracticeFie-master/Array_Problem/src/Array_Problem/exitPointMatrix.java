package Array_Problem;
import java.util.*;
public class exitPointMatrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int row1, col1;
	    Scanner s = new Scanner(System.in);
	    System.out.print("Enter number of rows in matrix:");
	    row1 = s.nextInt();
	    System.out.print("Enter number of columns in  matrix:");
	    col1 = s.nextInt();
	    int [][] a=new int[row1][col1];
	    System.out.println("Enter values for matrix A : \n");
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) 
                a[i][j] = s.nextInt();
        }
        
        System.out.println("Your Input Matrix  : \n");
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) {
                System.out.print(a[i][j]+"\t");}
            System.out.println();
        }
        int dir=0;
        int i=0;
        int j=0;
        while(true)
        {
           dir=dir+a[i][j]%4;
        	if(dir==0)//east
        	{
        		j++;//col inc row fixed
        	}
        	//if any 1 comes dir changes to south 
        	else if(dir==1)//south 
        	{
        		i++;// row inc col fixed
        	}
        	//if 1 comes dir changes to west 
        	else if(dir==2)
        	{
        		j--;//col dec while row is fixed
        	}
        	//if 1 comes then dir changes to North
        	else if(dir==3)
        	{
        	   i--;	
        	}
        	if(i<0)
        	{
        		i++;
        		break;
        	}
        	else if(j<0)
        	{
        		j++;
        		break;
        	}
        	else if(i==row1)
        	{
        		i--;
        		break;
        	}
        	else if(j== col1)
        	{
        		j--;
        		break;
        	}
        }
        
        System.out.println("Exit point of Matrix : a["+i +"]["+j+"]");
        

	}

}
