package Array_Problem;
import java.util.*;
public class shellRotation {
	public static void reverse(int [] arr,int start,int end)
	{
		int s1;
		int e1;
		while(end >= start)
		{
			s1=arr[start];
			e1=arr[end];
			arr[start]=e1;
			arr[end]=s1;
			end--;
			start++;
			
		}
	}
	public static int [][] fillshell(int [][]a ,int[]oned,int s)
	{
		int min_row=s-1;
		int min_col=s-1;
		int max_row=a.length-1;
		int max_col=a.length-1;
		int size= 2*max_row +2* max_col -2* min_row - 2*min_col;
		
	int ind=0;
	int i,j;
		//left wall row changes from min_row to  max_row col is fixed at min_col
    	for( i=min_row ,j=min_col;i<=max_row;i++)
    		//checking total_number of element greater than count
    	{
    		 a[i][j]=oned[ind];
    		 ind++;
    		 
    	}
    	//condition to remove corner :use only once
    	min_col++;
    	//bottom wall where row value is fixed at max_row while col changes from min_col to max_col
    	for( i=max_row,j=min_col;j<=max_col;j++)
    	{
    		 a[i][j]=oned[ind];
    		 ind++;
    	}
    		
    	max_row--;//condition to remove corner : corner use only once
    	//right wall col fixed at max_col row changes from max_row to min_row(dec)
    	for( i=max_row, j=max_col;i>=min_row ;i--)

    	{
    		 a[i][j]=oned[ind];
    		 ind++;
    	}
    	max_col--;//condition to remove corner : corner use only once
    	//Top wall row is fixed at min_row col is canges from max_col to min_col(dec)
    	for(i=min_row,j=max_col;j>=min_col;j--)
    	{
    		 a[i][j]=oned[ind];
    		 ind++;
    	}
    	return a;
	}
	public static int [] fillOned(int [][] a,int s)
	{
		int min_row=s-1;
		int min_col=s-1;
		int max_row=a.length-1;
		int max_col=a.length-1;
		int size= 2*max_row +2* max_col -2* min_row - 2*min_col;
		int [] oned=new int[size];
	int ind=0;
	int i,j;
		//left wall row changes from min_row to  max_row col is fixed at min_col
    	for( i=min_row ,j=min_col;i<=max_row;i++)
    		//checking total_number of element greater than count
    	{
    		 oned[ind]=a[i][j];
    		 ind++;
    		 
    	}
    	//condition to remove corner :use only once
    	min_col++;
    	//bottom wall where row value is fixed at max_row while col changes from min_col to max_col
    	for( i=max_row,j=min_col;j<=max_col;j++)
    	{
    		 oned[ind]=a[i][j];
    		 ind++; 
    	}
    		
    	max_row--;//condition to remove corner : corner use only once
    	//right wall col fixed at max_col row changes from max_row to min_row(dec)
    	for( i=max_row, j=max_col;i>=min_row ;i--)

    	{
    		 oned[ind]=a[i][j];
    		 ind++; 
    	}
    	max_col--;//condition to remove corner : corner use only once
    	//Top wall row is fixed at min_row col is canges from max_col to min_col(dec)
    	for(i=min_row,j=max_col;j>=min_col;j--)
    	{
    		 oned[ind]=a[i][j];
    		 ind++;
    	}
    	return oned;
	}
	public static void rotate(int [] oned,int key)
	{
		int size1=oned.length;
		//part1
				// from 0 to size-key-1
				reverse(oned, 0, size1-key-1);
				//part2
				// from size-key   to size-1
				reverse(oned, size1-key,size1-1);
				//part3
				//Reverse entire array
				reverse(oned,0,size1-1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int row1, col1;
	    Scanner s = new Scanner(System.in);
	    System.out.print("Enter number of rows in matrix:");
	    row1 = s.nextInt();
	    System.out.print("Enter number of columns in  matrix:");
	    col1 = s.nextInt();
	    int [][] a=new int[row1][col1];
	    System.out.println("Enter values for matrix A : \n");
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) 
                a[i][j] = s.nextInt();
        }
        System.out.print("Enter The Shell number which you want to rotate :");
	    int shell = s.nextInt();
	    System.out.print("Enter The number of times you want to rotate shell :");
	    int k = s.nextInt();
	    
        
        System.out.println("Your Input Matrix  : \n");
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) {
                System.out.print(a[i][j]+"\t");}
            System.out.println();
        }
            /*
             * Three Steps for output
             * 1.fill one d array from shell element
             * 2.rotate one d array by k
             * 3.fill the shell with update array value
             */
            //step1
            int []oned=fillOned(a, shell);
            //step2
            rotate(oned,k);
            //step3
            int [][]out=fillshell(a,oned,shell);
            System.out.println("Output Matrix : \n");
            for ( k = 0; k < row1; k++) {
                for (int j = 0; j < col1; j++) {
                	System.out.print(out[k][j]+"\t");
                	}
                System.out.println();
            }
            
            
        }

	}


