package Array_Problem;
import java.util.*;
public class Bar_Chart {
	public static void printBarchart(int []arr,int size)
	{
		int max=arr[0];
		for(int i=0;i<size;i++)
		{
			if(max<arr[i])
			{
				max=arr[i];
			}
		}
		for(int i=max;i>=1;i--)
		{
			for(int j=0;j<size;j++)
			{
				if(arr[j]>=i)
				{
				    System.out.print("*\t");
			    }
				else
				{
			      System.out.print("\t");
		       }
			}
		System.out.println();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Size Of Array ");
		int size=sc1.nextInt();
		int []arr=new int[size];
		System.out.println("Enter Element into  Array ");
		for(int i=0;i<size;i++)
		{
			arr[i]=sc1.nextInt();
		}
		
		printBarchart(arr,size);

	}

}
