package Array_Problem;

import java.util.Scanner;

public class rotateArray {
	public static void reverse(int [] arr,int start,int end)
	{
		int s1;
		int e1;
		while(end >= start)
		{
			s1=arr[start];
			e1=arr[end];
			arr[start]=e1;
			arr[end]=s1;
			end--;
			start++;
			
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Size Of  Array ");
		int size1=sc1.nextInt();
		int []arr=new int[size1];
		System.out.println("Enter Element into  Array ");
		for(int i=0;i<size1;i++)
		{
			arr[i]=sc1.nextInt();
		}
		System.out.println("Enter rotation number  ");
		int key =sc1.nextInt();
		System.out.println("Element of  Array before rotation  ");
		for(int i=0;i<size1;i++)
		{
			System.out.print("\t"+arr[i]);
		}

		//part1
		// from 0 to size-key-1
		reverse(arr, 0, size1-key-1);
		//part2
		// from size-key   to size-1
		reverse(arr, size1-key,size1-1);
		//part3
		//Reverse entire array
		reverse(arr,0,size1-1);
		System.out.println("\nElement of  Array After Rotation ");
		for(int i=0;i<size1;i++)
		{
			System.out.print("\t"+arr[i]);
		}
		
		

	}

}
