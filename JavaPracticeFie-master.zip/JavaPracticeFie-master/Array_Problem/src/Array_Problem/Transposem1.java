package Array_Problem;
import java.util.*;
public class Transposem1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int row1, col1;
	    Scanner s = new Scanner(System.in);
	    System.out.print("Enter number of rows in matrix:");
	    row1 = s.nextInt();
	    System.out.print("Enter number of columns in  matrix:");
	    col1 = s.nextInt();
	    int [][] a=new int[row1][col1];
	    System.out.println("Enter values for matrix A : \n");
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) 
                a[i][j] = s.nextInt();
        }
        
        System.out.println("Your Input Matrix  : \n");
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) {
                System.out.print(a[i][j]+"\t");}
            System.out.println();
        }
        int [][] out=new int[row1][col1];
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) 
                out[i][j] = a[j][i];
        }
        
        System.out.println("Transpose of  Matrix  : \n");
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) {
                System.out.print(out[i][j]+"\t");}
            System.out.println();
        }

	}

}
