package Array_Problem;

import java.util.Scanner;

public class arrayDiff {
	public static void arrayDiff(int []arr1,int []arr2,int size1,int size2)
	{
		int carry=0;
		int i=size1-1;
		int j=size2-1;
		int k=size2-1;
		int [] res=new int[size2];
		int d=0;
		while(k>=0)
		{
			d=0;
			int val=i >=0 ? arr1[i] : 0;
			   if(arr2[j]-carry >= val)
				{
					d=arr2[j]-val-carry;
					carry=0;
				}
				else
				{
					d=arr2[j]+10-val-carry;
					carry=1;
				}
			
			res[k]=d;
			i--;
			k--;
			j--;
		}
		int ind=0;
		while(ind < size2)
		{
			if(res[ind]==0)
			{
				ind++;
			}
			else
			{
				break;
			}
		}
		//for removing 0 before number
		
		for(int p=ind;p<size2;p++)
		{
			System.out.print(res[p]);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Size Of First Array ");
		int size1=sc1.nextInt();
		int []arr1=new int[size1];
		System.out.println("Enter Element into  First Array ");
		for(int i=0;i<size1;i++)
		{
			arr1[i]=sc1.nextInt();
		}
		
		System.out.println("Enter Size Of Second Array ");
		int size2=sc1.nextInt();
		int []arr2=new int[size2];
		System.out.println("Enter Element into Second  Array ");
		for(int i=0;i<size2;i++)
		{
			arr2[i]=sc1.nextInt();
		}
		
		System.out.println("Difference  Of Both Array  ");
		arrayDiff(arr1,arr2,size1,size2);

	}

}
