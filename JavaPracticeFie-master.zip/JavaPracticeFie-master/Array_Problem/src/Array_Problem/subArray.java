package Array_Problem;
import java.util.*;
public class subArray {
	public static void subarray(int [] arr,int n)
	{
		int i=0;
		while(i < n)
		{
			for(int j=i;j<n;j++)
			{
				for(int k=i;k<=j;k++) {
				System.out.print(arr[k]+"\t");
				}
				System.out.println();
			}
			
			i++;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Size Of  Array ");
		int size1=sc1.nextInt();
		int []arr=new int[size1];
		System.out.println("Enter Element into  Array ");
		for(int i=0;i<size1;i++)
		{
			arr[i]=sc1.nextInt();
		}
		System.out.println("Subarray Of Given Array ");
		subarray(arr,size1);

	}

}
