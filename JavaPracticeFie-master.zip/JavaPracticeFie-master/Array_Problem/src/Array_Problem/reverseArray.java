package Array_Problem;
import java.util.*;
public class reverseArray {
	public static int [] reverseArr(int [] arr1,int size)
	{
		int i=0;
		int j=size-1;
	    int tempi,tempj;
	    while(j >= i)
	    {
	    	tempi=arr1[i];
	    	tempj=arr1[j];
	    	arr1[i]=tempj;
	    	arr1[j]=tempi;
	    	j--;
	    	i++;
	    }
	    return arr1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Size Of  Array ");
		int size1=sc1.nextInt();
		int []arr1=new int[size1];
		System.out.println("Enter Element into  Array ");
		for(int i=0;i<size1;i++)
		{
			arr1[i]=sc1.nextInt();
		}
		
		System.out.println("Array Element Before reverse  ");
		for(int i=0;i<size1;i++)
		{
			System.out.print("\t"+arr1[i]);
		}
		 int []arr_res=reverseArr(arr1,size1);
		System.out.println("\nArray Element After reverse  ");
		for(int i=0;i<size1;i++)
		{
			System.out.print("\t"+arr_res[i]);
		}
		

	}

}
