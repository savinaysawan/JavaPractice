package Array_Problem;
import java.util.*;
public class ceilfloorArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Size Of Array ");
		int size=sc1.nextInt();
		int []arr=new int[size];
		System.out.println("Enter Element into  Array ");
		for(int i=0;i<size;i++)
		{
			arr[i]=sc1.nextInt();
		}
		System.out.println("Enter Key for Search in Array ");
		int key =sc1.nextInt();
		int mid;
		int floor=0;
		int ceil=0;
		int high=size-1;
		int low=0;
		while(high>=low)
		{
			mid=(high+low)/2;
			if(arr[mid]==key)
			{
				ceil=arr[mid];
				floor=arr[mid];
				break;
			}
			else if(arr[mid] < key)
			{
				low=mid+1;
				floor=arr[mid];
			}
			else
			{
				high=mid-1;
				ceil=arr[mid];
			}
			
		}
		System.out.println("Ceil of Given Array : " +ceil);
		System.out.println("Floor of Given Array : " +floor);

	}

}
