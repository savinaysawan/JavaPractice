package Array_Problem;
import java.util.*;
public class diagonalTraversal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int row1, col1;
	    Scanner s = new Scanner(System.in);
	    System.out.print("Enter number of rows in matrix:");
	    row1 = s.nextInt();
	    System.out.print("Enter number of columns in  matrix:");
	    col1 = s.nextInt();
	    int [][] a=new int[row1][col1];
	    System.out.println("Enter values for matrix A : \n");
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) 
                a[i][j] = s.nextInt();
        }
        
        System.out.println("Your  matrix A : \n");
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) { 
            	   System.out.print(a[i][j]+"\t");}
            System.out.println();
        }
        System.out.println("Diagonal Element of  matrix A : \n");
        for (int d = 0; d < row1; d++)//no of diagonals 
        {
        	for(int i=0,j=d;j<row1;i++,j++)//for diagonal 0 start a00 and difference in 0 i&j
        	{
        		System.out.println(a[i][j]);//every time diagonal start with next j value
        	}
        		
        }
            
        

	    }

}
