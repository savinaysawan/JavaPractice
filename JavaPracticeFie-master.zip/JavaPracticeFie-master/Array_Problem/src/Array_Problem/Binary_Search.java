package Array_Problem;
import java.util.*;
/* Binary search takes only sorted array
 * Not valid for unsorted array
 */

public class Binary_Search {
	public static int binarySearch(int [] arr,int low,int high,int key)
	{
		int mid;
		while(high>=low)
		{
			mid=(high+low)/2;
			if(arr[mid]==key)
			{
				return mid+1;
			}
			else if(arr[mid]<key)
			{
				low=mid+1;
			}
			else
			{
				high=mid-1;
			}
			
		}
		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Size Of Array ");
		int size=sc1.nextInt();
		int []arr=new int[size];
		System.out.println("Enter Element into  Array ");
		for(int i=0;i<size;i++)
		{
			arr[i]=sc1.nextInt();
		}
		System.out.println("Enter Key for Search in Array ");
		int key =sc1.nextInt();
		int f=binarySearch(arr,0,size-1,key);
		if(f!=-1) {
			System.out.println("Key  : "+key+"   Found At "+ f + "   position ");
		}
		else
		{
			System.out.println("Key  : "+key+"  Not  Found In Array ");
		}

	}

}
