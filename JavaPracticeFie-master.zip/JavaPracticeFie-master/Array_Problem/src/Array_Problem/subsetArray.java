package Array_Problem;
import java.util.*;
public class subsetArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Size Of  Array ");
		int size1=sc1.nextInt();
		int []arr=new int[size1];
		System.out.println("Enter Element into  Array ");
		for(int i=0;i<size1;i++)
		{
			arr[i]=sc1.nextInt();
		}
		int rem;
		int limit=(int)Math.pow(2,size1);
		//loop for decimal value 
		for(int i=0;i<limit;i++)
		{
			String set="";
			int temp=i;
			for(int j=0;j<size1;j++)
			{
				rem=temp%2;
				temp=temp/2;
				if(rem==0)
				{
					set="_\t"+set;
				}
				else
				{
					set=arr[j]+"\t"+set;
				}
			}
			System.out.println(set);
		}

	}

}
