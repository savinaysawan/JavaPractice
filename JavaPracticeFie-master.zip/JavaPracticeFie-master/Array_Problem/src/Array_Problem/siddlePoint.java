package Array_Problem;
import java.util.*;
public class siddlePoint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int row1, col1;
		boolean flag=true;
	    Scanner s = new Scanner(System.in);
	    System.out.print("Enter number of rows in matrix:");
	    row1 = s.nextInt();
	    System.out.print("Enter number of columns in  matrix:");
	    col1 = s.nextInt();
	    int [][] a=new int[row1][col1];
	    System.out.println("Enter values for matrix A : \n");
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) 
                a[i][j] = s.nextInt();
        }
        System.out.println("Your  matrix A : \n");
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) { 
            	   System.out.print(a[i][j]+"\t");}
            System.out.println();
        }
        int min_row=0;
        int i;
        for( i=0;i<row1;i++)

        {
        	for(int j=0;j<col1;j++) //finding maximum value of each row 
        	{
        	if(a[i][min_row] > a[i][j])
        		min_row=j;
        	}
        	 flag=true;
        	
        	//finding that minimum is maximum of col or not
        	for(int k=0;k<row1;k++)//investing in each row
        	{
        		if(a[k][min_row]<a[i][min_row])//if someone else is greater then we are unable to get siddle 
        		{
        			flag=false;
        			break;
        		}
        	}
        
        }
        if(flag==true)
        {
        	System.out.println("Siddle Point : "+a[i][min_row]);
        }
        else
        {
        	System.out.println("Invalid , No Siddle Point ");
        }

	}

}
