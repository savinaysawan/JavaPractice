package Array_Problem;
import java.util.*;
public class findingFirstLast {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Size Of Array ");
		int size=sc1.nextInt();
		int []arr=new int[size];
		System.out.println("Enter Element into  Array ");
		for(int i=0;i<size;i++)
		{
			arr[i]=sc1.nextInt();
		}
		System.out.println("Enter Key for Search in Array ");
		int key =sc1.nextInt();
		int mid;
		int low=0;
		int high=size-1;
		int first=-1;
		int last=-1;
		while(high>=low)
		{
			mid=(high+low)/2;
			if(arr[mid]==key)
			{
				first=mid;
				low=mid+1;
			}
			else if(arr[mid]<key)
			{
				low=mid+1;
			}
			else
			{
				high=mid-1;
			}
			
		}
		
		 low=0;
		 high=size-1;
		while(high>=low)
		{
			mid=(high+low)/2;
			if(arr[mid]==key)
			{
				last=mid;
				high=mid-1;
			}
			else if(arr[mid]<key)
			{
				low=mid+1;
			}
			else
			{
				high=mid-1;
			}
			
		}
		System.out.println("First Occurance index  :"+first);
		System.out.println("Last  Occurance index  :"+last);

	}

}
