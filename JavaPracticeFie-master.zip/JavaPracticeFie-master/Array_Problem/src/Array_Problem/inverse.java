package Array_Problem;
import java.util.*;
public class inverse {
	public static int[] inverse(int [] arr,int size)
	{
		int []arr1=new int[size];
		int temp;
		for(int i=0;i<size;i++)
		{
			temp=arr[i];
			arr1[temp]=i;
		}
		return arr1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Size Of  Array ");
		int size1=sc1.nextInt();
		int []arr=new int[size1];
		System.out.println("Enter Element into  Array ");
		for(int i=0;i<size1;i++)
		{
			arr[i]=sc1.nextInt();
		}
		System.out.println("Element of  Array before Inversion  ");
		for(int i=0;i<size1;i++)
		{
			System.out.print("\t"+arr[i]);
		}
		int [] res= inverse(arr,size1);
		System.out.println("\nElement of  Array After Inversion  ");
		for(int i=0;i<size1;i++)
		{
			System.out.print("\t"+res[i]);
		}

	}

}
