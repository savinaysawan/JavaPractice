package Array_Problem;

import java.util.Scanner;

public class linearSearch {
	public static int linearSearch(int [] arr,int n,int key)
	{
		int res=-1;
		for(int i=0; i<n;i++)
		{
			if(key==arr[i])
			{
				res=i+1;
				break;
			}
		}
		return res;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Size Of Array ");
		int size=sc1.nextInt();
		int []arr=new int[size];
		System.out.println("Enter Element into  Array ");
		for(int i=0;i<size;i++)
		{
			arr[i]=sc1.nextInt();
		}
		System.out.println("Enter Key for Search in Array ");
		int key =sc1.nextInt();
		int f=linearSearch(arr,size,key);
		if(f!=-1) {
			System.out.println("Key  : "+key+"   Found At "+ f + "   position ");
		}
		else
		{
			System.out.println("Key  : "+key+"  Not  Found In Array ");
		}

	}

}
