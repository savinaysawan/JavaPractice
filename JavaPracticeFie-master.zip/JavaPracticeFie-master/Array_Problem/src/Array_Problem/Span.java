package Array_Problem;
import java.util.*;
public class Span {
	public static int spanArray(int [] arr, int n)
	{
		int min=Integer.MAX_VALUE;
		int max=Integer.MIN_VALUE;
		for(int i=0;i<n;i++)
		{
			if(max <arr[i])
			{
				max=arr[i];
			}
		}
		for(int i=0;i<n;i++)
		{
			if(min > arr[i])
			{
				min=arr[i];
			}
		}
		return max-min;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Size Of Array ");
		int size=sc1.nextInt();
		int []arr=new int[size];
		System.out.println("Enter Element into  Array ");
		for(int i=0;i<size;i++)
		{
			arr[i]=sc1.nextInt();
		}
		System.out.println("Span Of Given Array : "+spanArray(arr,size));
		

	}

}
