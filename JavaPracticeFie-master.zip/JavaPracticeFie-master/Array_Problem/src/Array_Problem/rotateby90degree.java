package Array_Problem;
import java.util.*;
public class rotateby90degree {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int row1, col1;
	    Scanner s = new Scanner(System.in);
	    System.out.print("Enter number of rows in matrix:");
	    row1 = s.nextInt();
	    System.out.print("Enter number of columns in  matrix:");
	    col1 = s.nextInt();
	    int [][] a=new int[row1][col1];
	    System.out.println("Enter values for matrix A : \n");
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) 
                a[i][j] = s.nextInt();
        }
        
        System.out.println("Your Input Matrix  : \n");
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) {
                System.out.print(a[i][j]+"\t");}
            System.out.println();
        }
        //Step 1: Finding Transpose of Array /Matrix
        int temp;
        for(int i=0;i<row1;i++)
        {
        	for(int j=i;j<col1;j++)
        	{
        		temp=a[i][j];
        		a[i][j]=a[j][i];
        		a[j][i]=temp;
        	}
        }
        //Step 2: Reversing the first with last and so on
        int first=0;
        int last=col1-1;
        int swapTemp;
        for(int i=0;i<row1;i++)
        {
        	while(first>last)
        	{
        		swapTemp=a[i][first];
        		a[i][first]=a[i][last];
        		a[i][last]=swapTemp;
        		first++;//inc first 
        		last--;//dec last
        	}
        }
        
        System.out.println("Matrix with 90 Degree Rotation  : \n");
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) {
                System.out.print(a[i][j]+"\t");}
            System.out.println();
        }


	}

}
