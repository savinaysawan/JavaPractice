package Array_Problem;
import java.util.*;
public class arraySum {
	public static void sumArray(int [] arr1 , int [] arr2,int size1, int size2)
	{
		int carry=0;
		int max=size1>size2?size1:size2;
		int i=size1-1;
		int j=size2-1;
		int k=max-1;
		int [] res=new int[max];
		int d=0;
		while(k >= 0)
		{
			d=0;
			d=d+carry;
		if(i>=0)
		{
			d=d+arr1[i];
		}
		if(j>=0)
		{
			d=d+arr2[j];
		}
		carry=d/10;
		d=d%10;
		res[k]=d;
		i--;
		j--;
		k--;
		}
		if(carry>0)
		{
			System.out.print(carry);
		}
		for(int p=0;p<max;p++)
		{
			System.out.print(res[p]);
		}
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter Size Of First Array ");
		int size1=sc1.nextInt();
		int []arr1=new int[size1];
		System.out.println("Enter Element into  First Array ");
		for(int i=0;i<size1;i++)
		{
			arr1[i]=sc1.nextInt();
		}
		
		System.out.println("Enter Size Of Second Array ");
		int size2=sc1.nextInt();
		int []arr2=new int[size2];
		System.out.println("Enter Element into Second  Array ");
		for(int i=0;i<size2;i++)
		{
			arr2[i]=sc1.nextInt();
		}
		
		System.out.println("Sum Of Both Array  ");
		sumArray(arr1,arr2,size1,size2);

	}

}
