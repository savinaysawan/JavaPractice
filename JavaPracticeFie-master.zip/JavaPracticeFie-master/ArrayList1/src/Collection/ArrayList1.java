package Collection;

import java.util.ArrayList;

public class ArrayList1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList l1=new ArrayList(5);
		ArrayList l2=new ArrayList(3);
		
		l1.add(1);
		l1.add(2);
		l1.add(3);
		l1.add(4);
		l1.add(5);
		
		//l1.remove(1);
		/*
		l2.add(3);
		l2.add(4);
		l2.add(5);
		l1.retainAll(l2);
		*/
		/*
		l2.add(3);
		l2.add(4);
		l2.add(5);
		l1.removeAll(l2);
		*/
		System.out.println("l1 is Empty  :"+l1.isEmpty());
		
		System.out.println("Size :"+l1.size());
		
		 for (int i = 0; i < l1.size(); i++)
	            System.out.print(l1.get(i) + " ");
		


	}

}
