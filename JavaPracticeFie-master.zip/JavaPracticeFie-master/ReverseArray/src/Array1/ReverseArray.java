package Array1;
import java.util.*;
public class ReverseArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Size Of Array ");
		int n=sc.nextInt();
		int arr[]=new int[n];
		int last=arr.length-1;
		int beg=0;
		int temp=0;
		System.out.println("Enter Size Of Array ");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Original  Array :");
		for(int i=0;i<n;i++)
		{
			System.out.print(arr[i]+ "  ");
		}
		
		while(beg<last)
		{
		  temp=arr[beg];
		  arr[beg]=arr[last];
		  arr[last]=temp;
		  last--;
		  beg++;
		  
		}
		
		System.out.println("\nReverse   Array :");
		for(int i=0;i<n;i++)
		{
			System.out.print(arr[i]+ "  ");
		}

	}

}
