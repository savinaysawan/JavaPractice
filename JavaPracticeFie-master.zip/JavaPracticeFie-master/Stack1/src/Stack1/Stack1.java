package Stack1;
import java.util.*;
public class Stack1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack s1 = new Stack();
		s1.push(10);
		s1.push(20);
		s1.push(30);
		s1.push(40);
		s1.push(50);
		System.out.println("Top of Stack :"+s1.peek());
		System.out.println("Element of Stack is : ");
		System.out.println(s1);
		System.out.println(s1.pop());
		System.out.println("Searching Of Element 40 in Stack at :"+s1.search(40));
		
		

	}

}
