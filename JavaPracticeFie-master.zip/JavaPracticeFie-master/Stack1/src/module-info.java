module Stack1 {
}