module Stack_Problem {
}