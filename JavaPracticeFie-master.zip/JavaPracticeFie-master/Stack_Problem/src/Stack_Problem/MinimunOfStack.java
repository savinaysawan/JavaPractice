package Stack_Problem;
import java.util.*;
public class MinimunOfStack {
	Stack <Integer> stack1 = new Stack<>();
	Stack <Integer> stackMin = new Stack<>();
		public class StackOper{
			
			 //Push methode
			  void push(int element)
			 {
				 if(stack1.size()==0 )//first element push in both stack
				 {
					stack1.push(element);
					stackMin.push(element);
				 }
				 else
				 {
					 if(stackMin.peek()>element)
					 {
						 stackMin.push(element);
						 stack1.push(element);
					 }
					 else
					 {
						 stack1.push(element);
					 }
				 }
			 }
			 //pop method
			void pop()
			 {
				 if(stack1.size()==0)
				 {
					 System.out.println("Stack Underflow . Pop Cannot possible ");
					 
				 }
				 else
				 {
					 int val=stack1.pop();
					 if(val==stackMin.peek())
					 {
						 stackMin.pop();
					 }
				 }
				 System.out.println("!!!  POP Succesfully Done !!!");
			 }
			 //Size return no of element in Stack
			 int stackSize()
			 {
				 return stack1.size();
			 }
			 //top return the top element
			 int top()
			 {
				 if(stack1.size()==0)
				 {
					 System.out.println("Stack Underflow . top Cannot exists");
					 return -1;
				 }
				 else
				 {
					 return stack1.peek();
				 }
			 }
			 //Display method to display the element of Stack 
			 /*void display()
			 {
				 while (stack1.hasMoreElements()) 
				 {
			            System.out.println(stack1.nextElement());
				 }
				 
				 System.out.println();
			 }
			 */
			 int minElement()
			 {
				 if(stack1.size()==0)
				 {
					 System.out.println("Stack Underflow . Minimum Cannot exists");
				 }
				 else
				 {
					 return stackMin.peek();
				 }
			 }
		}	 

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Scanner sc1= new Scanner(System.in);
			/*
			 * User name and greeting
			 */
			System.out.println("Your Good Name Please :  ");
			String name =sc1.nextLine();
			System.out.println("Hi  "+name +"  Welcome \n");
			StackOper st=new StackOper();
			boolean i=true;
			while(i )
			{
				System.out.println("\n\nPress : 1  --->  for Push an element into Stack");
				System.out.println("Press : 2  --->  for Pop an element from Stack");
				System.out.println("Press : 3  --->  for Size/Number of element into Stack");
				System.out.println("Press : 4  --->  for top element of  Stack");
				System.out.println("Press : 5  --->  for Display all element of Stack");
				System.out.println("Press : 6  --->  for Display Minimum element of Stack");
				System.out.println("Press : any other integer to come out of loop  ");
				System.out.println("\n\nHi "+name+"   Please Enter Your Chioce given above");
				int s= sc1.nextInt();
				switch(s)
				{
				case 1:
					System.out.println("Enter element for pushing ");
					int ele=sc1.nextInt();
					st.push(ele);
					break;
				case 2:
					st.pop();
					
					break;
				case 3:
					System.out.println("Size of Stack is Main Stack:"+st.stackSize());
					break;
				case 4:
					int k2=st.top();
					if(k2 !=-1)
					{
						System.out.println("Top element of Stack  : "+k2);
					}
					else
					{
						System.out.println("No Top Element :");
					}
					break;
				/*case 5:
					System.out.println(" Element  of Stack IS :");
					st.display();
					break;
					*/
				case 6:
					System.out.println(" Minimum Element  of Stack IS :"+st.minElement());
					break;
				default :
					i=false;
					break;
					
					
					
				}
				
				
			}
			System.out.println("\n\nThank You   "+name +" For Using Code !!!!");
			System.out.println("\nrerun your code if u want to use these method again");

		}

	}


}
