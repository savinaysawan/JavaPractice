package Stack_Problem;
import java.util.Scanner;
import java.util.Stack;
public class celebrityProblem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Size of Array ");
		int size=sc.nextInt();
		int [][]arr=new int[size][size];
		System.out.println("Enter Element into Array \n");
		for(int i=0;i<size;i++)
		{
			for(int j=0;j<size;j++)
			{
			arr[i][j]=sc.nextInt();
			}
		}
		Stack<Integer> st=new Stack<>();
		for(int i=0;i<arr.length;i++)//pushing all element into stack
		{
			st.push(i);
		}
		//finding the potential celebrity
		while(st.size()>=2)
		{
			int i=st.pop();
			int j=st.pop();
			if(arr[i][j]==1)// i know j means i is not celebrity
			{
			  st.push(j);	
			}
			else
			{
				st.push(i);
			}
		}
		//assign the potential celebrity
		int pot=st.pop();//potential celebrity
		for(int i=0;i<size;i++)
		{
			if(i != pot)
			{
				if(arr[i][pot]==0 || arr[pot][i]==1)// if breaking celebrity rule
				{
					System.out.println("No celebrity Possible");
					return;
				}
			}
		}
		System.out.println("Celebrity "+pot);

	}

}
