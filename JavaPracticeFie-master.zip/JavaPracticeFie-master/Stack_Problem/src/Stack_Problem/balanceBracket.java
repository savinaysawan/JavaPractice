package Stack_Problem;

import java.util.*;


public class balanceBracket {
	public static int  checkclosing(Stack<Character>st, char ch)
	{
		if(st.size()==0)//nothing in Stack means new bracket is extra
		{
		   return 0;
		   
		}
		/*
		 * if opening bracket is differ from closing bracket we get then we return false
		 */
		else if(st.peek()!=ch)//In top we have different symbol [  ch=} then differ value
		{
			return 0;
		}
		else//value match then pop
		{
			st.pop();
		}
		return 1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		String str;
		System.out.println("Enter Expression for evoluation : ");
		str=sc.nextLine();
		int  b=1;
		Stack <Character> st= new Stack<>();
		for(int i=0;i<str.length();i++)
		{
			char ch=str.charAt(i);
			//if we get opening bracket then push it
			if(ch=='('|| ch=='{' || ch=='[')
			{
				st.push(ch);
			}
			else if(ch==')')
			{
				 b=checkclosing(st,ch);
			}
			else if(ch=='}')
			{
				b=checkclosing(st,ch);
			}
			else if(ch==']')
			{
				 b=checkclosing(st,ch);
			}
		}
		if(b==1)
		{
			System.out.println("Enter Expression having Balance Brackets : ");
		}
		else
		{
			System.out.println("Enter Expression Not  Balance Brackets : ");
		}

	}

}
