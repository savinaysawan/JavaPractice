package Stack_Problem;
import java.util.*;
/*
 * (a+b)+(a+b)
False
((a+b)+(a+b))
False

(a+)+((a+b)) true double () only single also enough
 */
public class duplicateBracket {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		String str;
		System.out.println("Enter Expression for evoluation : ");
		str=sc.nextLine();
		int flag=0;
		Stack<Character> st= new Stack<>();
		for(int i=0;i<str.length();i++)
		{
			char ch=str.charAt(i);
			if(ch==')')//if closing bracket comes we need to check otherwise all element should push
			{
				if(st.peek()=='(')
				{
					flag=1;
					break ;
				}
				else
				{
					while(st.peek()!='(')
					{
						st.pop();
						
					}
					st.pop();
				}
			}
			else//all element pushed 
			{
				st.push(ch);
			}
		}
		if(flag==1)
		{
			System.out.println("True ");
		}
		else
		{
		System.out.println("False");
		}

	}

}
