package Stack_Problem;
import java.util.*;
public class dynamicStack {
	public static class stackClass
	{
		int []stack1 ;
	
		int tos;
		 public stackClass(int size)
		{
			stack1=new int[size];
			tos=-1;
			
		}
		 //Push methode
		 void push(int element)
		 {
			 if(tos==stack1.length -1 )
			 {
				 //stack with double size
				 int []nstack= new int[2 *stack1.length];
				 //copy value from prev stack
				 for(int i=0;i<stack1.length;i++)
				 {
					 nstack[i]=stack1[i];
					 
				 }
				 stack1=nstack;
				 //putting value into top of stack 
				 stack1[++tos]=element;
				 
			 }
			 else
			 {
				 stack1[++tos]=element;
			 }
		 }
		 //pop method
		 int pop()
		 {
			 if(tos==-1)
			 {
				 System.out.println("Stack Underflow . Pop Cannot possible ");
				 return -1;
			 }
			 else
			 {
				 int pop_element=stack1[tos--];
				 return pop_element;
			 }
		 }
		 //Size return no of element in Stack
		 int stackSize()
		 {
			 return tos+1;
		 }
		 //top return the top element
		 int top()
		 {
			 if(tos==-1)
			 {
				 System.out.println("Stack Underflow . top Cannot exists");
				 return -1;
			 }
			 else
			 {
				 return stack1[tos];
			 }
		 }
		 //Display method to display the element of Stack 
		 void display()
		 {
			 for(int i=tos;i>=0;i--)
			 {
				 System.out.println(stack1[i]+"  ");
			 }
			 System.out.println();
		 }
		 
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc1= new Scanner(System.in);
		/*
		 * User name and greeting
		 */
		System.out.println("Your Good Name Please :  ");
		String name =sc1.nextLine();
		System.out.println("Hi  "+name +"  Welcome \n");
		System.out.println("Enter Size of stack that you want to create  ");
		int si=sc1.nextInt();
		stackClass st=new stackClass(si);
		boolean i=true;
		while(i )
		{
			
			System.out.println("\n\nPress : 1  --->  for Push an element into Dynamic Stack");
			System.out.println("Press : 2  --->  for Pop an element from Dyanamic Stack");
			System.out.println("Press : 3  --->  for Size/Number of element into Dynamic Stack");
			System.out.println("Press : 4  --->  for top element of Dynamic Stack");
			System.out.println("Press : 5  --->  for Display all element of Dynamic Stack");
			System.out.println("Press : any other integer to come out of loop  ");
			System.out.println("\n\nHi "+name+"   Please Enter Your Chioce given above");
			int s= sc1.nextInt();
			switch(s)
			{
			case 1:
				System.out.println("Enter element for pushing ");
				int ele=sc1.nextInt();
				st.push(ele);
				break;
			case 2:
				int k=st.pop();
				if(k!=-1)
				{
					System.out.println("pop element : "+k);
				}
				else
				{
					System.out.println("Not possible:");
				}
				break;
			case 3:
				System.out.println("Size of Stack is :"+st.stackSize());
				break;
			case 4:
				int k2=st.top();
				if(k2 !=-1)
				{
					System.out.println("Top element of Stack  : "+k2);
				}
				else
				{
					System.out.println("No Top Element :");
				}
				break;
			case 5:
				System.out.println(" Element  of Stack IS :");
				st.display();
				break;
			default :
				i=false;
				break;
				
				
				
			}
			
			
		}
		System.out.println("\n\nThank You   "+name +" For Using Code !!!!");
		System.out.println("\nrerun your code if u want to use these method again");

	}

}
