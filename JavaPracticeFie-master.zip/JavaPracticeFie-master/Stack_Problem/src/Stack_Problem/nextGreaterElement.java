package Stack_Problem;
import java.util.*;
public class nextGreaterElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Size of Array ");
		int size=sc.nextInt();
		int []arr=new int[size];
		int []out=new int[size];
		System.out.println("Enter Element into Array \n");
		for(int i=0;i<size;i++)
		{
			arr[i]=sc.nextInt();
		}
		Stack<Integer> st=new Stack<>();
		st.push(arr[size-1]);
		out[size-1]=-1;//setting last index to -1.
		for(int i=size-2;i>=0;i--)
		{
			while(st.size() >0 && arr[i] >=st.peek())//Element in stack & fetch element is greater
			{
				st.pop();
			}
			if(st.size()==0)//if stack becomes empty
			{
				out[i]=-1;//assign -1 into stack
			}
			else
			{
				out[i]=st.peek();
			}
			st.push(arr[i]);
		}
		System.out.println(" Element Of Given Array  \n");
		for(int i=0;i<size;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println("\nNext Greater Element Of Given Array  \n");
		for(int i=0;i<size;i++)
		{
			System.out.print(out[i]+" ");
		}
		
		
		

	}

}
