package Stack_Problem;
import java.util.*;
public class Basic_Method {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Scanner sc= new Scanner(System.in);
		String str;
		System.out.println("Enter Expression ");
		str=sc.nextLine();
		*/
		Stack <Integer> st= new Stack<>();
		st.push(100);
		st.push(200);
		st.push(300);
		st.push(400);
		
		System.out.println("Stack Data :"+st);
		System.out.println("Stack Size :"+st.size());
		System.out.println("Stack Capacity :"+st.capacity());//default size 10
		st.pop();//pop peek element from Stack
		System.out.println("Stack Data :"+st);
		System.out.println("Stack Size :"+st.size());//7542058766
		System.out.println("Peek Element Of Stack :"+st.peek());
	}

}
