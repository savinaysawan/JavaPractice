package Stack_Problem;
import java.util.*;
public class mergeMettingInterval {
	public static void merge(int [][] arr)
	{
		pair [] pairs = new pair[arr.length];//Creating object of pair
		for(int i=0;i<arr.length;i++)
		{
			pairs[i]=new pair(arr[i][0],arr[i][1]);//data stored  in pair (start and end )
		}
		Arrays.sort(pairs);
		Stack <pair> s1= new Stack<>();
		for(int i=0;i<pairs.length;i++)
		{
			if(i==0)
			{
				s1.push(pairs[i]);//firs element push blindly . from second we need comparision and push
			}
			else
			{
				pair top=s1.peek();
				if(pairs[i].st > top.end)
				{
					s1.push(pairs[i])//if next start is greater than prev end .directly push 
				}
				else
				{
					top.end=Math.max(top.end, pais[i].end);
				}
			}
		}
	}
	public static class pair implenents Comparable<pair>
	{
		int st;
		int end;
		pair(int st , int end)
		{
			this.st=st;
			this.end=end;
		}
		public int compareTo(pair other)//for sorting
		{
			if(st != other.st)//ot this.st
			{
				return st-other.st;
			}
			else
			{
				return end-other.end;
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number of Interval Pair");
		int n=sc.nextInt();
		int [][] arr=new int[n][n];
		for(int i=0;i<n;i++)
		{
		   arr[i][0]=sc.nextInt();//start of interval
		   arr[i][1]=sc.nextInt();//end of interval
		}
		merge(arr);

	}

}
