package Stack_Problem;
import java.util.*;
/*
 * Input 100, 80, 60, 70, 60, 75, 85
 * Output {1, 1, 1, 2, 1, 4, 6} 
 */
public class stockSpan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Size Of Array ");
		int size=sc.nextInt();
		int arr[]=new int[size];
		System.out.println("Enter Element into Array ");
		for(int i=0;i<size;i++)
		{
			arr[i]=sc.nextInt();
		}
		int span[]= new int[size];
		Stack <Integer> st=new Stack<>();
		//first element push
		st.push(0);
		span[0]=1;
		//work with second to all element
		for(int i=1;i<arr.length;i++)
		{
			while(st.size()>0 && arr[i]>=arr[st.peek()])//pop till smallest element comes or stack becomes empty
			{
				st.pop();
			}
			//case 1: if stack becomes empty spna value is index+1
			if(st.size()==0)
			{
				span[i]=i+1;
			}
			else // all smallest element is pop peek is greatest element
			{
			  span[i]=i-st.peek();	
			}
			//push index to stack
			st.push(i);
		}
		System.out.println("Original Array\n  ");
		for(int i=0;i<size;i++)
		{
			System.out.print(arr[i]+" ");
		}
		
		System.out.println("\nSpan  Array\n  ");
		for(int i=0;i<size;i++)
		{
			System.out.print(span[i]+" ");
		}

	}

}
