package Stack_Problem;
import java.util.*;
public class nextGreaterElementMethod2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Size of Array ");
		int size=sc.nextInt();
		int []arr=new int[size];
		int []out=new int[size];
		System.out.println("Enter Element into Array \n");
		for(int i=0;i<size;i++)
		{
			arr[i]=sc.nextInt();
			out[i]=-1;
		}
		Stack<Integer> st=new Stack<>();
		for(int i=0;i<arr.length;i++)
		{
			while(st.size()>0 && arr[st.peek()]<arr[i])//whenever value in stack and next greater value coming 
				//we pop element and assign them with greater value
			{
				out[st.pop()]=arr[i];//assign greater value for respective data  
			}
			st.push(i);//pushing the index for further processing
		}
		System.out.println("\nElement of Array \n");
		for(int i=0;i<size;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println("\nNext Greater element  of Array \n");
		for(int i=0;i<size;i++)
		{
			System.out.print(out[i]+" ");
		}

	}

}
