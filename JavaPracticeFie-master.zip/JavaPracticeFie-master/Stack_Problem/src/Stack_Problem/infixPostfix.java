/*
 *output :
 * Enter Expression for Change (Infix to Prefix)  : 
a+b*c+(d+e)
Infix Expression: a+b*c+(d+e)
Postfix Expression: abc*+de++

 */


package Stack_Problem;
import java.util.*;
public class infixPostfix {
	 static int precedence(char c){
	        switch (c){
	            case '+':
	            case '-':
	                return 1;
	            case '*':
	            case '/':
	                return 2;
	            case '^':
	                return 3;
	        }
	        return -1;
	    }

	    static String infixToPostFix(String expression){

	        String result = "";
	        Stack<Character> stack = new Stack<>();
	        for (int i = 0; i <expression.length() ; i++) 
	        {
	            char c = expression.charAt(i);

	            //check if char is operator -1 return means operand or bracket there not operator 
	            if(precedence(c)>0){
	                while(stack.isEmpty()==false && precedence(stack.peek())>=precedence(c)){
	                    result += stack.pop();
	                }
	                stack.push(c);
	            }
	            else if(c==')')
	            {
	                char x = stack.pop();
	                while(x!='('){
	                    result += x;
	                    x = stack.pop();
	                }
	            }
	            else if(c=='(')
	            {
	                stack.push(c);
	            }
	            else
	            {
	                //character is neither operator nor ( 
	                result += c;
	            }
	        }
	        for (int i = 0; i <=stack.size() ; i++) {
	            result += stack.pop();
	        }
	        return result;
	    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		String str;
		System.out.println("Enter Expression for Change (Infix to Prefix)  : ");
		str=sc.nextLine();
		System.out.println("Infix Expression: " + str);
        System.out.println("Postfix Expression: " + infixToPostFix(str));
		

	}

}
